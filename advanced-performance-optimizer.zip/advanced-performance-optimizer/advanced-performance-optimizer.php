<?php
/**
 * Plugin Name: Advanced Performance Optimizer
 * Plugin URI: https://yourwebsite.com
 * Description: A professional caching and performance optimization plugin with advanced features.
 * Version: 1.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * License: GPLv2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Admin Menu Creation
add_action('admin_menu', 'advanced_performance_optimizer_menu');

function advanced_performance_optimizer_menu() {
    add_menu_page(
        'Performance Optimizer',   
        'Performance Optimizer',            
        'manage_options',          
        'advanced-performance-optimizer-settings',   
        'advanced_performance_optimizer_settings_page' 
    );
}

// Settings Page
function advanced_performance_optimizer_settings_page() {
    ?>
    <div class="wrap">
        <h1>Advanced Performance Optimizer Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('advanced_performance_optimizer_settings_group');
            do_settings_sections('advanced-performance-optimizer-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Register Settings
add_action('admin_init', 'advanced_performance_optimizer_settings');

function advanced_performance_optimizer_settings() {
    register_setting('advanced_performance_optimizer_settings_group', 'cache_enabled');
    register_setting('advanced_performance_optimizer_settings_group', 'minify_css_js');
    register_setting('advanced_performance_optimizer_settings_group', 'gzip_compression');
    
    add_settings_section('advanced_performance_optimizer_main', 'Performance Settings', null, 'advanced-performance-optimizer-settings');

    // Cache Toggle
    add_settings_field(
        'cache_enabled',
        'Enable Cache',
        'cache_enabled_callback',
        'advanced-performance-optimizer-settings',
        'advanced_performance_optimizer_main'
    );

    // Minify CSS & JS
    add_settings_field(
        'minify_css_js',
        'Minify CSS and JavaScript',
        'minify_css_js_callback',
        'advanced-performance-optimizer-settings',
        'advanced_performance_optimizer_main'
    );

    // GZIP Compression
    add_settings_field(
        'gzip_compression',
        'Enable GZIP Compression',
        'gzip_compression_callback',
        'advanced-performance-optimizer-settings',
        'advanced_performance_optimizer_main'
    );
}

// Callbacks for Settings
function cache_enabled_callback() {
    $cache_enabled = get_option('cache_enabled');
    ?>
    <input type="checkbox" name="cache_enabled" value="1" <?php checked(1, $cache_enabled, true); ?> />
    Enable caching
    <?php
}

function minify_css_js_callback() {
    $minify_css_js = get_option('minify_css_js');
    ?>
    <input type="checkbox" name="minify_css_js" value="1" <?php checked(1, $minify_css_js, true); ?> />
    Minify CSS and JavaScript files
    <?php
}

function gzip_compression_callback() {
    $gzip_compression = get_option('gzip_compression');
    ?>
    <input type="checkbox" name="gzip_compression" value="1" <?php checked(1, $gzip_compression, true); ?> />
    Enable GZIP compression
    <?php
}

// Enable Caching
if (get_option('cache_enabled')) {
    add_action('init', 'start_caching');
}

function start_caching() {
    if (!is_admin()) {
        ob_start('cache_output');
    }
}

function cache_output($buffer) {
    $cache_file = plugin_dir_path(__FILE__) . 'cache/index.html';
    if (!file_exists(plugin_dir_path(__FILE__) . 'cache')) {
        mkdir(plugin_dir_path(__FILE__) . 'cache', 0755, true);
    }
    file_put_contents($cache_file, $buffer);
    return $buffer;
}

// Minification Function
if (get_option('minify_css_js')) {
    add_action('wp_enqueue_scripts', 'minify_files', 20);
}

function minify_files() {
    global $wp_styles, $wp_scripts;

    // Minify CSS
    foreach ($wp_styles->registered as $handle => $data) {
        if (strpos($data->src, '.css') !== false) {
            $css_content = file_get_contents($data->src);
            $minified_css = preg_replace('/\s+/', ' ', $css_content);
            file_put_contents($data->src, $minified_css);
        }
    }

    // Minify JS
    foreach ($wp_scripts->registered as $handle => $data) {
        if (strpos($data->src, '.js') !== false) {
            $js_content = file_get_contents($data->src);
            $minified_js = preg_replace('/\s+/', ' ', $js_content);
            file_put_contents($data->src, $minified_js);
        }
    }
}

// Enable GZIP Compression
if (get_option('gzip_compression')) {
    add_action('init', 'enable_gzip_compression');
}

function enable_gzip_compression() {
    if (!ob_start("ob_gzhandler")) {
        ob_start();
    }
}

// Plugin Activation and Deactivation
register_activation_hook(__FILE__, 'advanced_performance_optimizer_activate');
register_deactivation_hook(__FILE__, 'advanced_performance_optimizer_deactivate');

function advanced_performance_optimizer_activate() {
    add_option('cache_enabled', 0);
    add_option('minify_css_js', 0);
    add_option('gzip_compression', 0);
}

function advanced_performance_optimizer_deactivate() {
    delete_option('cache_enabled');
    delete_option('minify_css_js');
    delete_option('gzip_compression');
}
